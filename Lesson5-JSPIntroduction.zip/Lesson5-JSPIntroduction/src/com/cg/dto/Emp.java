package com.cg.dto;

public class Emp {
	private int eid;
	private String enm;
	private double esl;
	public int getEid() {
		return eid;
	}
	public String getEnm()
	{
		return enm;
	}
	public double getEsl()
	{
		return esl;
	}
	public void setEid(int eid) 
	{
		this.eid = eid;
	}
	public void setEnm(String enm)
	{
		this.enm = enm;
	}
	public void setEsl(double esl)
	{
		this.esl = esl;
	}                                

}   
